(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const config = window.ONECORD_CONFIG || { API_BASE_URL: '', CHAT_ENDPOINT: '/api/chat', STATUS_ENDPOINT: '/api/status' };
  const state = { page: 'home', selectedServer: '', level: 0, busy: false, toastTimer: null };
  const levels = [
    { name: 'Low', description: 'Quick responses with a lighter reasoning level.' },
    { name: 'Balanced', description: 'A balance of speed and depth.' },
    { name: 'High', description: 'More detailed responses for harder tasks.' },
    { name: 'Pro', description: 'This level may require an eligible plan.' },
    { name: 'Max', description: 'This level may require an eligible plan.' }
  ];

  const icons = {
    close: '<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>'
  };
  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => node.classList.remove('show'), 2600);
  }
  function closePopovers(except) {
    $$('.popover').forEach(pop => { if (pop !== except) pop.hidden = true; });
    $$('.quick-action, .model-button').forEach(button => button.classList.remove('active'));
  }
  function togglePopover(id, anchor) {
    const pop = $(id);
    const alreadyOpen = !pop.hidden;
    closePopovers();
    if (!alreadyOpen) {
      pop.hidden = false;
      if (anchor) anchor.classList.add('active');
      positionPopover(pop, anchor);
    }
  }
  function positionPopover(pop, anchor) {
    // Keep the desktop popovers near the controls; mobile popovers intentionally center like the reference UI.
    if (window.matchMedia('(max-width: 760px)').matches || !anchor) return;
    const r = anchor.getBoundingClientRect();
    const w = Math.min(pop.offsetWidth || 410, window.innerWidth - 24);
    const h = pop.offsetHeight || 220;
    let left = Math.max(12, Math.min(r.left + r.width / 2 - w / 2, window.innerWidth - w - 12));
    let top = r.top - h - 12;
    if (top < 12) top = Math.min(window.innerHeight - h - 12, r.bottom + 12);
    pop.style.left = `${left}px`;
    pop.style.top = `${Math.max(12, top)}px`;
    pop.style.right = 'auto';
    pop.style.bottom = 'auto';
    pop.style.transform = 'none';
  }
  function setPage(page) {
    state.page = page;
    $$('.page').forEach(node => node.classList.toggle('visible', node.id === `page-${page}`));
    $$('.nav-item[data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === page));
    closePopovers();
    closeSidebar();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (page === 'home') setTimeout(() => $('#promptInput').focus({ preventScroll: true }), 100);
  }
  function openSidebar() {
    $('#sidebar').classList.add('open');
    $('#sidebarBackdrop').classList.add('visible');
  }
  function closeSidebar() {
    $('#sidebar').classList.remove('open');
    $('#sidebarBackdrop').classList.remove('visible');
  }
  function fitTextarea(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 140)}px`;
  }
  function appendMessage(text, role, extraClass = '') {
    const area = $('#conversationArea');
    area.classList.add('has-content');
    const node = document.createElement('div');
    node.className = `message ${role}${extraClass ? ` ${extraClass}` : ''}`;
    node.textContent = text;
    area.appendChild(node);
    area.scrollTop = area.scrollHeight;
  }
  async function sendChat(text) {
    const prompt = text.trim();
    if (!prompt || state.busy) return;
    setPage('home');
    $('#conversationArea').classList.add('has-content');
    appendMessage(prompt, 'user');
    $('#promptInput').value = '';
    fitTextarea($('#promptInput'));
    state.busy = true;
    $('#sendButton').disabled = true;
    $('#sendButton').style.opacity = '.65';
    try {
      if (config.API_BASE_URL && !config.API_BASE_URL.includes('your-api.example.com')) {
        const base = config.API_BASE_URL.replace(/\/$/, '');
        const response = await fetch(`${base}${config.CHAT_ENDPOINT || '/api/chat'}`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: prompt, server: state.selectedServer || null, model: 'GPT-6 Luna', level: levels[state.level].name })
        });
        if (!response.ok) throw new Error(`The API returned ${response.status}.`);
        const data = await response.json();
        const reply = data.reply ?? data.message ?? data.response;
        if (typeof reply !== 'string') throw new Error('The API response did not include a text reply.');
        appendMessage(reply, 'assistant');
      } else {
        appendMessage('The interface is running in demo mode. Add your backend URL to config.js to receive real assistant responses. Your message has not been sent to an external service.', 'assistant');
      }
    } catch (error) {
      appendMessage(`Could not reach the API. ${error.message} Check the backend URL and make sure CORS allows this website.`, 'assistant', 'error');
    } finally {
      state.busy = false;
      $('#sendButton').disabled = false;
      $('#sendButton').style.opacity = '';
      $('#promptInput').focus({ preventScroll: true });
    }
  }
  function selectServer(name) {
    state.selectedServer = name;
    $('#chosenServerText').textContent = name;
    $('#serverPopover').hidden = true;
    $('#chooseServerButton').classList.remove('active');
    toast(`Selected ${name} (demo)`);
  }
  function applyLevel(value) {
    state.level = Number(value);
    $('#modelLevelText').textContent = levels[state.level].name;
    $('#modelLevelPopoverText').textContent = levels[state.level].name;
    $('#rangeDescription').textContent = levels[state.level].description;
  }
  function resetDemo() {
    state.selectedServer = '';
    state.level = 0;
    $('#chosenServerText').textContent = 'Choose server';
    $('#conversationArea').innerHTML = '';
    $('#conversationArea').classList.remove('has-content');
    $('#promptInput').value = '';
    applyLevel(0);
    closePopovers();
    setPage('home');
    toast('Demo reset');
  }

  // Navigation and menus
  $$('.nav-item[data-page]').forEach(button => button.addEventListener('click', () => setPage(button.dataset.page)));
  $('#brandButton').addEventListener('click', () => setPage('home'));
  $('#mobileBrandButton').addEventListener('click', () => setPage('home'));
  $('#mobileMenuToggle').addEventListener('click', openSidebar);
  $('#closeSidebarButton').addEventListener('click', closeSidebar);
  $('#sidebarBackdrop').addEventListener('click', closeSidebar);
  $('#newChatButton').addEventListener('click', resetDemo);
  $('#mobileNewChat').addEventListener('click', resetDemo);
  $('#searchButton').addEventListener('click', () => { toast('Search is a visual demo in this version.'); });
  $('#mobileSearch').addEventListener('click', () => { toast('Search is a visual demo in this version.'); });
  $('#chooseServerButton').addEventListener('click', e => togglePopover('#serverPopover', e.currentTarget));
  $('#pluginsButton').addEventListener('click', e => togglePopover('#pluginsPopover', e.currentTarget));
  $('#modelButton').addEventListener('click', e => togglePopover('#modelPopover', e.currentTarget));
  $('#profileButton').addEventListener('click', e => togglePopover('#accountPopover', e.currentTarget));
  $('#inviteButton').addEventListener('click', () => toast('Add your own invite or referral URL here.'));
  $('#accountHelpButton').addEventListener('click', () => setPage('help'));
  $('#accountResetButton').addEventListener('click', resetDemo);
  $('#browsePluginsButton').addEventListener('click', () => setPage('plugins'));
  $('#popoverBrowseButton').addEventListener('click', () => setPage('plugins'));
  $('#serverSearch').addEventListener('input', e => {
    const needle = e.target.value.toLowerCase();
    $$('.server-option').forEach(row => { row.hidden = !row.textContent.toLowerCase().includes(needle); });
  });
  $$('.server-option').forEach(row => row.addEventListener('click', () => selectServer(row.dataset.server || row.textContent.trim())));
  $('#pluginSearch').addEventListener('input', () => {});
  $('#modelRange').addEventListener('input', e => {
    const val = Number(e.target.value);
    // Demo interface: higher two levels appear locked, but remain selectable for visual testing.
    applyLevel(val);
    if (val >= 3) $('#rangeDescription').textContent = `${levels[val].description} Demo only — no subscription is checked.`;
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.popover') && !e.target.closest('#chooseServerButton') && !e.target.closest('#pluginsButton') && !e.target.closest('#modelButton') && !e.target.closest('#profileButton')) closePopovers();
  });
  window.addEventListener('resize', () => {
    const open = $$('.popover').find(p => !p.hidden);
    if (open && !window.matchMedia('(max-width: 760px)').matches) {
      const map = { serverPopover: '#chooseServerButton', pluginsPopover: '#pluginsButton', modelPopover: '#modelButton', accountPopover: '#profileButton' };
      const trigger = $(map[open.id]);
      positionPopover(open, trigger);
    }
  });

  // Chat composer
  $('#chatForm').addEventListener('submit', e => { e.preventDefault(); sendChat($('#promptInput').value); });
  $('#promptInput').addEventListener('input', e => fitTextarea(e.currentTarget));
  $('#promptInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(e.currentTarget.value); }
  });
  $('#attachButton').addEventListener('click', () => toast('Attachments are not connected in this demo.'));
  $('#micButton').addEventListener('click', () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { toast('Voice input is not supported by this browser.'); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = navigator.language || 'en-US';
    recognition.onresult = event => { $('#promptInput').value += event.results[0][0].transcript; fitTextarea($('#promptInput')); $('#promptInput').focus(); };
    recognition.onerror = () => toast('Voice input was not available.');
    recognition.start();
  });

  // Template gallery
  $$('.template-card').forEach(card => card.addEventListener('click', () => {
    $('#imagePromptInput').value = card.dataset.prompt || '';
    fitTextarea($('#imagePromptInput'));
    $('#imagePromptInput').focus({ preventScroll: true });
    toast('Template prompt added');
  }));
  $('#imageForm').addEventListener('submit', e => {
    e.preventDefault();
    const prompt = $('#imagePromptInput').value.trim();
    if (!prompt) { toast('Describe the image you want to create first.'); return; }
    toast('Image generation needs an image API connected to your backend.');
  });
  $('#imageAttachButton').addEventListener('click', () => toast('Image attachments are not connected in this demo.'));
  $('#imageMicButton').addEventListener('click', () => toast('Voice input for image prompts is not connected here.'));

  // Optional, non-blocking status ping to a backend. This never exposes API credentials.
  if (config.API_BASE_URL && !config.API_BASE_URL.includes('your-api.example.com')) {
    fetch(`${config.API_BASE_URL.replace(/\/$/, '')}${config.STATUS_ENDPOINT || '/api/status'}`, { headers: { Accept: 'application/json' } })
      .then(response => { if (!response.ok) throw new Error('status endpoint not reachable'); return response.json(); })
      .then(data => { document.documentElement.dataset.apiStatus = data.status || 'connected'; })
      .catch(() => { document.documentElement.dataset.apiStatus = 'unavailable'; });
  }
})();
