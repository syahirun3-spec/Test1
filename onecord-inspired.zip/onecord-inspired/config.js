/* Public frontend configuration.
   Keep secrets on your backend. Never add a Discord bot token here. */
window.ONECORD_CONFIG = {
  // Replace with your deployed API URL, e.g. "https://your-api.example.com".
  // Leave empty to use local demo mode.
  API_BASE_URL: "",
  CHAT_ENDPOINT: "/api/chat",
  STATUS_ENDPOINT: "/api/status"
};
